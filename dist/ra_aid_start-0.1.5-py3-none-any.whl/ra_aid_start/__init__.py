"""
RA AID Start Package.

Este pacote contém a lógica principal para a ferramenta CLI RA AID Start,
incluindo gerenciamento de presets, modelos, interface de usuário e utilitários.
"""
# Initializes the ra_aid_start package