"""
UI Package for RA AID Start.

Este pacote contém os módulos responsáveis pela interface do usuário da aplicação,
incluindo o sistema de menus, assistentes de configuração e utilitários de display.
Utiliza bibliotecas como Rich e Click para a interação com o usuário no terminal.
"""
# Initializes the ui package