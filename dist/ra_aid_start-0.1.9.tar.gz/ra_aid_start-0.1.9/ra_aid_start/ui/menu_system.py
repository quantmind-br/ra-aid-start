"""
Sistema de Menus Interativos para RA AID Start.

Este módulo define a classe MenuSystem, responsável por apresentar
a interface de linha de comando principal da aplicação, permitindo
ao usuário navegar entre as funcionalidades de gerenciamento de presets,
modelos, execução de presets e outras operações.
"""
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.prompt import Prompt
from rich.table import Table
from rich.box import SIMPLE_HEAVY
from pathlib import Path # Para obter o diretório do usuário

# Adicionar o diretório raiz do projeto ao sys.path
import sys
import os
# Obtém o diretório do script atual (menu_system.py) -> ra_aid_start/ui
# Sobe dois níveis para obter o diretório raiz do projeto
project_root = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(project_root))

from ra_aid_start.core.preset_manager import PresetManager
from ra_aid_start.models.preset import Preset # Para type hinting
from ra_aid_start.core.model_manager import ModelManager
from ra_aid_start.models.model import Model # Para type hinting
from ra_aid_start.ui.display import display_error, display_info, display_success, display_warning, display_panel # Adicionado
from ra_aid_start.ui.wizards import ConfigurationWizard # Adicionado para integração
from ra_aid_start.models.validation import ValidationRules # Adicionado para ConfigurationWizard

class MenuSystem:
    """
    Gerencia a exibição e navegação dos menus da aplicação.
    """
    def __init__(self):
        self.console = Console()
        # Determinar o diretório base para os dados da aplicação
        # Usaremos ~/.ra-aid-start como padrão
        self.base_data_dir = Path.home() / ".ra-aid-start"
        self.presets_dir = self.base_data_dir / "presets"
        self.models_dir = self.base_data_dir / "models"
        
        self.preset_manager = PresetManager(base_storage_path=self.base_data_dir)
        self.model_manager = ModelManager(base_storage_path=self.base_data_dir)
        self.validation_rules = ValidationRules() # Instanciar para o Wizard

        self.options = {
            "1": "Selecionar e Executar Preset",
            "2": "Configurar/Editar Preset",
            "3": "Gerenciar Modelos",
            "4": "Backup/Restore",
            "5": "Sair"
        }

    def display_main_menu(self):
        """
        Exibe o menu principal formatado.
        """
        menu_text = Text("\nMenu Principal\n\n", justify="center", style="bold cyan")
        for key, value in self.options.items():
            menu_text.append(f"{key}. {value}\n", style="white")
        
        self.console.print(Panel(
            menu_text,
            title="[bold green]RA AID Start[/bold green]",
            expand=False,
            border_style="blue"
        ))

    def get_user_choice(self) -> str:
        """
        Captura a escolha do usuário.
        """
        choice = Prompt.ask("Escolha uma opção", choices=list(self.options.keys()), show_choices=False)
        return choice

    def run(self):
        """
        Loop principal do menu.
        """
        while True:
            self.display_main_menu()
            choice = self.get_user_choice()

            if choice == "1":
                self._handle_select_execute_preset()
            elif choice == "2":
                self._handle_manage_presets()
            elif choice == "3":
                self._handle_manage_models()
            elif choice == "4":
                display_warning("Opção 4 selecionada: Backup/Restore (Funcionalidade futura)")
                # Lógica para backup/restore
                pass
            elif choice == "5":
                display_info("Saindo...")
                break
            else:
                display_error("Opção inválida. Tente novamente.")
            
            Prompt.ask("\nPressione Enter para continuar...") # Pausa para o usuário ver a mensagem

    def _handle_select_execute_preset(self):
        """
        Lida com a lógica de selecionar e executar um preset.
        """
        self.console.print(Panel(Text("Selecionar e Executar Preset", justify="center", style="bold green")))
        
        presets = self.preset_manager.list_presets()

        if not presets:
            display_warning("Nenhum preset encontrado.")
            return

        table = Table(title="Presets Disponíveis", box=SIMPLE_HEAVY, show_lines=True)
        table.add_column("ID", style="dim", width=5, justify="center")
        table.add_column("Nome", style="cyan", min_width=20)
        table.add_column("Comando (Resumido)", style="magenta", min_width=30, overflow="ellipsis")

        preset_map = {} # Mapeia o número da lista para o nome do preset (ID)
        for i, preset_obj in enumerate(presets, 1): # preset_obj é um objeto Preset
            actual_preset_name_str = preset_obj.name # Usar o atributo .name para a string do nome
            try:
                # O objeto preset_obj de list_presets() já deve ter o comando.
                # Se não tiver, ou se quisermos garantir o mais recente, podemos carregar.
                # Por ora, vamos assumir que preset_obj.command é suficiente.
                if preset_obj.command:
                    command_summary = (preset_obj.command[:70] + "...") if len(preset_obj.command) > 70 else preset_obj.command
                else:
                    # Fallback: tentar carregar se o comando não estiver no objeto listado
                    # (Isso pode acontecer se o save_preset não conseguiu gerar o comando anteriormente)
                    loaded_for_command = self.preset_manager.load_preset(actual_preset_name_str)
                    if loaded_for_command and loaded_for_command.command:
                         command_summary = (loaded_for_command.command[:70] + "...") if len(loaded_for_command.command) > 70 else loaded_for_command.command
                    else:
                        command_summary = "N/A"
            except Exception:
                command_summary = "[dim]Erro ao obter comando[/dim]"
            
            table.add_row(str(i), actual_preset_name_str, command_summary) # Passar a string do nome
            preset_map[str(i)] = actual_preset_name_str # Mapear para o nome (string)
        
        self.console.print(table)

        if not preset_map: # Redundante devido à verificação anterior, mas seguro
            display_warning("Nenhum preset válido para seleção.")
            return

        choice = Prompt.ask("Escolha um preset pelo ID (número) ou 'v' para voltar", choices=list(preset_map.keys()) + ['v'], show_choices=False)

        if choice.lower() == 'v':
            return

        selected_preset_name = preset_map.get(choice)
        if not selected_preset_name:
            display_error("Seleção inválida.")
            return

        try:
            preset = self.preset_manager.load_preset(selected_preset_name)
            if not preset:
                display_error(f"Erro ao carregar o preset '{selected_preset_name}'.")
                return
        except Exception as e:
            display_error(f"Erro ao carregar o preset '{selected_preset_name}': {e}")
            return

        details_text = Text(f"Detalhes do Preset: {preset.name}\n\n", style="bold cyan")
        details_text.append(f"Nome: {preset.name}\n", style="white")
        details_text.append(f"Descrição: {preset.description or 'N/A'}\n", style="white")
        details_text.append(f"Comando Completo:\n", style="white")
        details_text.append(f"{preset.command}\n\n", style="yellow")
        
        self.console.print(Panel(
            details_text,
            title=f"[bold green]Preset: {preset.name}[/bold green]",
            expand=False,
            border_style="blue"
        ))

        sub_options = {
            "1": "Executar Preset",
            "2": "Apenas Mostrar Comando",
            "3": "Voltar"
        }
        sub_menu_text = Text("\nOpções:\n", style="bold")
        for k, v in sub_options.items():
            sub_menu_text.append(f"{k}. {v}\n")
        self.console.print(sub_menu_text)
        
        sub_choice = Prompt.ask("Escolha uma opção", choices=list(sub_options.keys()), show_choices=False)

        if sub_choice == "1":
            display_info(f"Executando preset '{preset.name}'...")
            try:
                # Garantir que o PresetManager tenha sido inicializado corretamente
                # Se o preset_manager foi inicializado no __init__ da classe, ele já deve estar pronto
                self.preset_manager.execute_preset(preset.name)
                display_success(f"Preset '{preset.name}' executado (ou comando enviado para execução).")
            except Exception as e:
                display_error(f"Erro ao executar o preset '{preset.name}': {e}")
        elif sub_choice == "2":
            display_info(f"Comando para '{preset.name}':\n{preset.command}", title="Comando do Preset")
        elif sub_choice == "3":
            return # Volta ao menu principal

    def _handle_manage_presets(self):
        """
        Lida com a lógica de gerenciar presets (criar, editar, excluir, etc.).
        """
        manage_options = {
            "1": "Criar Novo Preset",
            "2": "Editar Preset Existente",
            "3": "Excluir Preset",
            "4": "Visualizar Preset",
            "5": "Importar Presets",
            "6": "Exportar Presets",
            "7": "Voltar ao Menu Principal"
        }

        while True:
            self.console.print(Panel(Text("Gerenciar Presets", justify="center", style="bold green")))
            
            menu_text = Text()
            for key, value in manage_options.items():
                menu_text.append(f"{key}. {value}\n", style="white")
            self.console.print(menu_text)

            choice = Prompt.ask("Escolha uma opção", choices=list(manage_options.keys()), show_choices=False)

            if choice == "1": # Criar Novo Preset
                wizard = ConfigurationWizard(
                    preset_manager=self.preset_manager,
                    model_manager=self.model_manager,
                    validation_rules=self.validation_rules, # Passar ValidationRules
                    console=self.console
                )
                new_preset = wizard.start_wizard()
                if new_preset:
                    display_success(f"Novo preset '{new_preset.name}' criado através do assistente.")
                else:
                    display_warning("Criação de novo preset cancelada ou falhou no assistente.")
            elif choice == "2": # Editar Preset Existente
                self._select_and_perform_action_on_preset("editar")
            elif choice == "3": # Excluir Preset
                self._select_and_perform_action_on_preset("excluir")
            elif choice == "4": # Visualizar Preset
                self._select_and_perform_action_on_preset("visualizar")
            elif choice == "5": # Importar Presets
                display_warning("Funcionalidade 'Importar Presets' a ser implementada.")
                # Lógica para self.preset_manager.import_presets()
            elif choice == "6": # Exportar Presets
                display_warning("Funcionalidade 'Exportar Presets' a ser implementada.")
                # Lógica para self.preset_manager.export_presets()
            elif choice == "7": # Voltar
                break
            else:
                display_error("Opção inválida. Tente novamente.")
            
            if choice != "7": # Não pausar se estiver voltando
                Prompt.ask("\nPressione Enter para continuar...")

    def _select_and_perform_action_on_preset(self, action: str):
        """
        Lista presets e permite ao usuário selecionar um para uma ação específica (visualizar, excluir, editar).
        """
        self.console.print(Panel(Text(f"{action.capitalize()} Preset", justify="center", style="bold green")))
        
        presets = self.preset_manager.list_presets()
        if not presets:
            display_warning("Nenhum preset encontrado.")
            return

        table = Table(title="Presets Disponíveis", box=SIMPLE_HEAVY, show_lines=True)
        table.add_column("ID", style="dim", width=5, justify="center")
        table.add_column("Nome", style="cyan", min_width=20)

        preset_map = {}
        for i, preset_name in enumerate(presets, 1):
            table.add_row(str(i), preset_name)
            preset_map[str(i)] = preset_name
        
        self.console.print(table)

        if not preset_map:
            display_warning("Nenhum preset válido para seleção.")
            return

        choice = Prompt.ask(f"Escolha um preset pelo ID para {action} ou 'v' para voltar", choices=list(preset_map.keys()) + ['v'], show_choices=False)

        if choice.lower() == 'v':
            return

        selected_preset_name = preset_map.get(choice)
        if not selected_preset_name:
            display_error("Seleção inválida.")
            return

        try:
            preset = self.preset_manager.load_preset(selected_preset_name)
            if not preset:
                display_error(f"Erro ao carregar o preset '{selected_preset_name}'.")
                return
        except Exception as e:
            display_error(f"Erro ao carregar o preset '{selected_preset_name}': {e}")
            return

        if action == "visualizar":
            details_text = Text(f"Detalhes do Preset: {preset.name}\n\n", style="bold cyan")
            details_text.append(f"Nome: {preset.name}\n", style="white")
            details_text.append(f"Descrição: {preset.description or 'N/A'}\n", style="white")
            details_text.append(f"Comando Completo:\n", style="white")
            details_text.append(f"{preset.command}\n\n", style="yellow")
            self.console.print(Panel(details_text, title=f"[bold green]Preset: {preset.name}[/bold green]", expand=False, border_style="blue"))
        
        elif action == "excluir":
            confirm = Prompt.ask(f"Tem certeza que deseja excluir o preset '{preset.name}'? (s/n)", choices=["s", "n"], default="n")
            if confirm.lower() == 's':
                try:
                    if self.preset_manager.delete_preset(preset.name):
                        display_success(f"Preset '{preset.name}' excluído com sucesso.")
                    else:
                        # O delete_preset deve idealmente já logar/retornar erro específico
                        display_error(f"Erro ao excluir o preset '{preset.name}' (PresetManager).")
                except Exception as e:
                    display_error(f"Erro ao excluir o preset '{preset.name}': {e}")
            else:
                display_warning("Exclusão cancelada.")

        elif action == "editar":
            wizard = ConfigurationWizard(
                preset_manager=self.preset_manager,
                model_manager=self.model_manager,
                validation_rules=self.validation_rules, # Passar ValidationRules
                console=self.console
            )
            edited_preset = wizard.start_wizard(existing_preset_name=selected_preset_name) # Passar nome do preset
            if edited_preset:
                display_success(f"Preset '{edited_preset.name}' editado através do assistente.")
            else:
                display_warning(f"Edição do preset '{selected_preset_name}' cancelada ou falhou no assistente.")

    def _handle_manage_models(self):
        """
        Lida com a lógica de gerenciar modelos LLM.
        """
        manage_models_options = {
            "1": "Visualizar Modelos por Provider",
            "2": "Adicionar Novo Modelo",
            "3": "Editar Modelo Existente",
            "4": "Remover Modelo",
            "5": "Importar Modelos",
            "6": "Exportar Modelos",
            "7": "Restaurar Modelos Padrões",
            "8": "Voltar ao Menu Principal"
        }

        while True:
            self.console.print(Panel(Text("Gerenciar Modelos LLM", justify="center", style="bold green")))
            
            menu_text = Text()
            for key, value in manage_models_options.items():
                menu_text.append(f"{key}. {value}\n", style="white")
            self.console.print(menu_text)

            choice = Prompt.ask("Escolha uma opção", choices=list(manage_models_options.keys()), show_choices=False)

            if choice == "1": # Visualizar Modelos por Provider
                self._view_models_by_provider()
            elif choice == "2": # Adicionar Novo Modelo
                display_warning("Funcionalidade 'Adicionar Novo Modelo' a ser implementada.")
            elif choice == "3": # Editar Modelo Existente
                display_warning("Funcionalidade 'Editar Modelo Existente' a ser implementada.")
            elif choice == "4": # Remover Modelo
                display_warning("Funcionalidade 'Remover Modelo' a ser implementada.")
            elif choice == "5": # Importar Modelos
                display_warning("Funcionalidade 'Importar Modelos' a ser implementada.")
            elif choice == "6": # Exportar Modelos
                display_warning("Funcionalidade 'Exportar Modelos' a ser implementada.")
            elif choice == "7": # Restaurar Modelos Padrões
                self._restore_default_models()
            elif choice == "8": # Voltar
                break
            else:
                display_error("Opção inválida. Tente novamente.")
            
            if choice != "8":
                Prompt.ask("\nPressione Enter para continuar...")

    def _view_models_by_provider(self):
        """
        Permite ao usuário selecionar um provider e visualizar seus modelos.
        """
        self.console.print(Panel(Text("Visualizar Modelos por Provider", justify="center", style="bold green")))
        
        # O ModelManager não tem um método direto para listar providers,
        # então vamos listar os arquivos .json no diretório de modelos.
        try:
            provider_files = [f.stem for f in self.models_dir.iterdir() if f.is_file() and f.suffix == '.json']
        except FileNotFoundError:
            display_warning(f"Diretório de modelos ({self.models_dir}) não encontrado.")
            return
        
        if not provider_files:
            display_warning("Nenhum provider (arquivo de modelo) encontrado.")
            return

        display_info("Providers disponíveis:")
        provider_map = {}
        for i, provider_name in enumerate(provider_files, 1):
            self.console.print(f"{i}. {provider_name}")
            provider_map[str(i)] = provider_name
        
        provider_choice = Prompt.ask("Escolha um provider pelo número ou 'v' para voltar", choices=list(provider_map.keys()) + ['v'], show_choices=False)

        if provider_choice.lower() == 'v':
            return

        selected_provider = provider_map.get(provider_choice)
        if not selected_provider:
            display_error("Seleção de provider inválida.")
            return

        try:
            models = self.model_manager.get_models_for_provider(selected_provider)
        except Exception as e:
            display_error(f"Erro ao carregar modelos para o provider '{selected_provider}': {e}")
            return

        if not models:
            display_warning(f"Nenhum modelo encontrado para o provider '{selected_provider}'.")
            return

        table = Table(title=f"Modelos para {selected_provider}", box=SIMPLE_HEAVY, show_lines=True)
        table.add_column("Nome", style="cyan", min_width=20)
        table.add_column("Descrição", style="magenta", min_width=30, overflow="ellipsis")
        table.add_column("Provider", style="green", min_width=15)
        table.add_column("É Padrão?", style="yellow", justify="center")

        for model in models:
            table.add_row(
                model.name,
                model.description or "N/A",
                model.provider,
                "Sim" if model.is_default else "Não"
            )
        self.console.print(table)

    def _restore_default_models(self):
        """
        Lida com a restauração dos modelos padrão.
        """
        confirm = Prompt.ask(
            "Tem certeza que deseja restaurar todos os modelos para os padrões de fábrica?\n"
            "Isso [bold red]SOBRESCREVERÁ[/bold red] quaisquer modelos existentes com o mesmo nome nos providers padrão.",
            choices=["s", "n"],
            default="n"
        )
        if confirm.lower() == 's':
            try:
                self.model_manager.restore_defaults()
                display_success("Modelos padrão restaurados com sucesso!")
            except Exception as e:
                display_error(f"Erro ao restaurar modelos padrão: {e}")
        else:
            display_warning("Restauração cancelada.")


if __name__ == "__main__":
    # Para testes locais, certifique-se de que os diretórios existem
    # ou que os Managers os criarão.
    # Exemplo:
    # test_presets_dir = Path.home() / ".ra-aid-start" / "presets"
    # test_models_dir = Path.home() / ".ra-aid-start" / "models"
    # test_presets_dir.mkdir(parents=True, exist_ok=True)
    # test_models_dir.mkdir(parents=True, exist_ok=True)
    
    menu = MenuSystem()
    menu.run()