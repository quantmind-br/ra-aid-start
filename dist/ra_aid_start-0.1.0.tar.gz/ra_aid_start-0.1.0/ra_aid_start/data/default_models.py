# ra_aid_start/data/default_models.py
"""
Este arquivo contém as definições de modelos LLM padrão para diferentes provedores.
A estrutura é um dicionário onde cada chave é o nome de um provedor e o valor
é uma lista de dicionários, cada um representando os dados de um modelo.
"""

DEFAULT_MODELS_DATA = {
    "OpenAI": [
        {
            "name": "gpt-4o",
            "provider": "OpenAI",
            "description": "O modelo mais recente e avançado da OpenAI, multimodal.",
            "recommended_for": ["geral", "chat", "análise", "geração de código"],
            "is_default": True,
            "supports_temperature": True,
            "context_window": 128000,
            "created_by": "system-default"
        },
        {
            "name": "gpt-4-turbo",
            "provider": "OpenAI",
            "description": "Modelo GPT-4 Turbo com janela de contexto de 128k e conhecimento até Abr 2023.",
            "recommended_for": ["geral", "chat", "análise complexa"],
            "is_default": False,
            "supports_temperature": True,
            "context_window": 128000,
            "created_by": "system-default"
        },
        {
            "name": "gpt-3.5-turbo",
            "provider": "OpenAI",
            "description": "Modelo rápido e econômico para tarefas gerais.",
            "recommended_for": ["chat rápido", "resumo", "tradução"],
            "is_default": False,
            "supports_temperature": True,
            "context_window": 16385,
            "created_by": "system-default"
        }
    ],
    "Anthropic": [
        {
            "name": "claude-3-opus-20240229",
            "provider": "Anthropic",
            "description": "O modelo mais poderoso da Anthropic para tarefas complexas.",
            "recommended_for": ["pesquisa", "desenvolvimento", "análise de alto nível"],
            "is_default": True,
            "supports_temperature": True,
            "context_window": 200000,
            "created_by": "system-default"
        },
        {
            "name": "claude-3-sonnet-20240229",
            "provider": "Anthropic",
            "description": "Equilíbrio ideal entre inteligência e velocidade para cargas de trabalho empresariais.",
            "recommended_for": ["processamento de dados", "recomendações", "geração de código"],
            "is_default": False,
            "supports_temperature": True,
            "context_window": 200000,
            "created_by": "system-default"
        },
        {
            "name": "claude-3-haiku-20240307",
            "provider": "Anthropic",
            "description": "O modelo mais rápido e compacto para capacidade de resposta quase instantânea.",
            "recommended_for": ["interação com cliente", "moderação de conteúdo", "tarefas de economia de custos"],
            "is_default": False,
            "supports_temperature": True,
            "context_window": 200000,
            "created_by": "system-default"
        }
    ],
    "Google": [
        {
            "name": "gemini-1.5-pro-latest",
            "provider": "Google",
            "description": "Modelo multimodal de médio porte da próxima geração, otimizado para uma ampla gama de tarefas.",
            "recommended_for": ["geral", "chat", "multimodal"],
            "is_default": True,
            "supports_temperature": True,
            "context_window": 1048576, # 1M tokens
            "created_by": "system-default"
        },
        {
            "name": "gemini-1.0-pro",
            "provider": "Google",
            "description": "Modelo de primeira geração otimizado para tarefas de linguagem natural.",
            "recommended_for": ["chat", "texto"],
            "is_default": False,
            "supports_temperature": True,
            "context_window": 32768,
            "created_by": "system-default"
        }
    ]
    # Adicione outros provedores e seus modelos padrão aqui
}

if __name__ == '__main__':
    # Exemplo de como acessar os dados
    print("Modelos padrão da OpenAI:")
    for model in DEFAULT_MODELS_DATA.get("OpenAI", []):
        print(f"  - {model['name']} (Default: {model.get('is_default', False)})")

    print("\nModelos padrão da Anthropic:")
    for model in DEFAULT_MODELS_DATA.get("Anthropic", []):
        print(f"  - {model['name']} (Default: {model.get('is_default', False)})")

    print("\nModelos padrão da Google:")
    for model in DEFAULT_MODELS_DATA.get("Google", []):
        print(f"  - {model['name']} (Default: {model.get('is_default', False)})")

    print(f"\nTotal de provedores com modelos padrão: {len(DEFAULT_MODELS_DATA)}")