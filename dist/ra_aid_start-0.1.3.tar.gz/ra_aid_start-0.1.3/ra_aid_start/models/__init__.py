"""
Models Package for RA AID Start.

Este pacote define os modelos de dados Pydantic usados em toda a aplicação,
como Preset e Model, e quaisquer regras de validação associadas.
"""
# Initializes the models package