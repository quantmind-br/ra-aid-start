"""
Utilities Package for RA AID Start.

Este pacote contém módulos utilitários diversos usados em toda a aplicação,
como manipuladores de arquivos JSON, gerenciadores de backup e outras
funções de suporte.
"""
# Initializes the utils package