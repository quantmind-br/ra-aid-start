"""
Core Logic Package for RA AID Start.

Este subpacote contém as classes e funcionalidades centrais da aplicação,
como gerenciamento de presets, modelos, construção de comandos e backups.
"""
# Initializes the core package